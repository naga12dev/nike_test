//
//  Genere.swift
//  NikeTestApp
//
//  Created by Harish on 05/03/20.
//  Copyright © 2020 Harish. All rights reserved.
//

import Foundation

struct Genere: Codable {
    let genreId: String
    let name: String
    let url: String
}
