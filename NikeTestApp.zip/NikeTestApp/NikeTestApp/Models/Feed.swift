//
//  Feed.swift
//  NikeTestApp
//
//  Created by Harish on 05/03/20.
//  Copyright © 2020 Harish. All rights reserved.
//

import Foundation

struct Feed: Codable {
    let feed: Results
}
